using UnityEngine;

public class ForcedReset : MonoBehaviour
{
}
