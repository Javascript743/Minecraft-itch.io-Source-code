using UnityEngine;

namespace UnityStandardAssets._2D
{
	public class Platformer2DUserControl : MonoBehaviour
	{
	}
}
