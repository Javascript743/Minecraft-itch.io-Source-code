using UnityEngine;

namespace UnityStandardAssets.Utility
{
	public class FPSCounter : MonoBehaviour
	{
	}
}
