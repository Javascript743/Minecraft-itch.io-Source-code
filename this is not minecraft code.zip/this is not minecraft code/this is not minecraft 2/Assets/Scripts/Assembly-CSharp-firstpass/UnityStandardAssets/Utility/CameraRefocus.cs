using UnityEngine;

namespace UnityStandardAssets.Utility
{
	public class CameraRefocus
	{
		public CameraRefocus(Camera camera, Transform parent, Vector3 origCameraPos)
		{
		}

		public Camera Camera;
		public Vector3 Lookatpoint;
		public Transform Parent;
	}
}
