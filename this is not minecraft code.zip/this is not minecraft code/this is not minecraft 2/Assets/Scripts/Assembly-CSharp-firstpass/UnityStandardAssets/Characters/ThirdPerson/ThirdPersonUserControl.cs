using UnityEngine;

namespace UnityStandardAssets.Characters.ThirdPerson
{
	public class ThirdPersonUserControl : MonoBehaviour
	{
	}
}
