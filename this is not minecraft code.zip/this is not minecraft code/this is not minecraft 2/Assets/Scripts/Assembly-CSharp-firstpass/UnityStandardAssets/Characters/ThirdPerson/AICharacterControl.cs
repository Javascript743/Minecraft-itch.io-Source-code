using UnityEngine;

namespace UnityStandardAssets.Characters.ThirdPerson
{
	public class AICharacterControl : MonoBehaviour
	{
		public Transform target;
	}
}
