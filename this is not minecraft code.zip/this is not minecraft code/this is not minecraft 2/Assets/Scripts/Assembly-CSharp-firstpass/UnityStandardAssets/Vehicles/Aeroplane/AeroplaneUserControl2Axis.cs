using UnityEngine;

namespace UnityStandardAssets.Vehicles.Aeroplane
{
	public class AeroplaneUserControl2Axis : MonoBehaviour
	{
		public float maxRollAngle;
		public float maxPitchAngle;
	}
}
