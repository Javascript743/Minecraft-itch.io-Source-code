using UnityEngine;

namespace UnityStandardAssets.Vehicles.Ball
{
	public class BallUserControl : MonoBehaviour
	{
	}
}
