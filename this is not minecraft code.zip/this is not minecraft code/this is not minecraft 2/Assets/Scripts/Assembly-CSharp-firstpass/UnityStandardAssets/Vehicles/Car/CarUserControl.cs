using UnityEngine;

namespace UnityStandardAssets.Vehicles.Car
{
	public class CarUserControl : MonoBehaviour
	{
	}
}
