namespace UnityStandardAssets.Vehicles.Car
{
	internal enum SpeedType
	{
		MPH = 0,
		KPH = 1,
	}
}
