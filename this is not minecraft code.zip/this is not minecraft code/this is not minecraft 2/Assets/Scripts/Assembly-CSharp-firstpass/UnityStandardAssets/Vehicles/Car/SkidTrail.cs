using UnityEngine;

namespace UnityStandardAssets.Vehicles.Car
{
	public class SkidTrail : MonoBehaviour
	{
		[SerializeField]
		private float m_PersistTime;
	}
}
