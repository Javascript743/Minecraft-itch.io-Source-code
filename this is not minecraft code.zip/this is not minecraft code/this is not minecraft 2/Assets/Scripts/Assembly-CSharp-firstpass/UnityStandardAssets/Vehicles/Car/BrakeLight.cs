using UnityEngine;

namespace UnityStandardAssets.Vehicles.Car
{
	public class BrakeLight : MonoBehaviour
	{
		public CarController car;
	}
}
