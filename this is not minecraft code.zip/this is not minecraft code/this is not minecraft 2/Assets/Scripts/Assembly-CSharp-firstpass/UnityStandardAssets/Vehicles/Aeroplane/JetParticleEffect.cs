using UnityEngine;

namespace UnityStandardAssets.Vehicles.Aeroplane
{
	public class JetParticleEffect : MonoBehaviour
	{
		public Color minColour;
	}
}
