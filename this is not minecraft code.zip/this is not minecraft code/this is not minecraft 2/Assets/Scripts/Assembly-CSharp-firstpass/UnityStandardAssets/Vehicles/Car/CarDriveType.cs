namespace UnityStandardAssets.Vehicles.Car
{
	internal enum CarDriveType
	{
		FrontWheelDrive = 0,
		RearWheelDrive = 1,
		FourWheelDrive = 2,
	}
}
