using UnityEngine;

namespace UnityStandardAssets.Vehicles.Aeroplane
{
	public class AeroplaneUserControl4Axis : MonoBehaviour
	{
		public float maxRollAngle;
		public float maxPitchAngle;
	}
}
