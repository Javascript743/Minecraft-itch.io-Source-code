using UnityEngine;

namespace UnityStandardAssets.Vehicles.Car
{
	public class WheelEffects : MonoBehaviour
	{
		public Transform SkidTrailPrefab;
		public ParticleSystem skidParticles;
	}
}
