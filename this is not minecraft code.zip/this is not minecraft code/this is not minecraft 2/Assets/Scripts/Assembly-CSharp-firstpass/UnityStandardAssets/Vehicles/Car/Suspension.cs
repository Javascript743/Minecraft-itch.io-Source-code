using UnityEngine;

namespace UnityStandardAssets.Vehicles.Car
{
	public class Suspension : MonoBehaviour
	{
		public GameObject wheel;
	}
}
