using UnityEngine;

namespace UnityStandardAssets.Vehicles.Car
{
	public class Mudguard : MonoBehaviour
	{
		public CarController carController;
	}
}
