using UnityEngine;

namespace UnityStandardAssets.Vehicles.Aeroplane
{
	public class LandingGear : MonoBehaviour
	{
		public float raiseAtAltitude;
		public float lowerAtAltitude;
	}
}
