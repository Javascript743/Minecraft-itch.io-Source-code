namespace UnityStandardAssets.CrossPlatformInput
{
	public class VirtualInput
	{
	}
}
