using UnityStandardAssets.CrossPlatformInput;

namespace UnityStandardAssets.CrossPlatformInput.PlatformSpecific
{
	public class StandaloneInput : VirtualInput
	{
	}
}
