using UnityEngine;

namespace UnityStandardAssets.CrossPlatformInput
{
	public class ButtonHandler : MonoBehaviour
	{
		public string Name;
	}
}
