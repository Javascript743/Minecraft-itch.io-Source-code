using UnityStandardAssets.CrossPlatformInput;

namespace UnityStandardAssets.CrossPlatformInput.PlatformSpecific
{
	public class MobileInput : VirtualInput
	{
	}
}
