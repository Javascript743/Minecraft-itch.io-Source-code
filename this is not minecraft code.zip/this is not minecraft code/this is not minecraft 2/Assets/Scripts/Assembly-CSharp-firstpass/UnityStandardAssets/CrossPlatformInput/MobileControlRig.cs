using UnityEngine;

namespace UnityStandardAssets.CrossPlatformInput
{
	public class MobileControlRig : MonoBehaviour
	{
	}
}
