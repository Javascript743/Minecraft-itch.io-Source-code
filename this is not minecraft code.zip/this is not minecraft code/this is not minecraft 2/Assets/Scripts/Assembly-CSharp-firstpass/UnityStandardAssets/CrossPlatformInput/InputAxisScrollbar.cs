using UnityEngine;

namespace UnityStandardAssets.CrossPlatformInput
{
	public class InputAxisScrollbar : MonoBehaviour
	{
		public string axis;
	}
}
