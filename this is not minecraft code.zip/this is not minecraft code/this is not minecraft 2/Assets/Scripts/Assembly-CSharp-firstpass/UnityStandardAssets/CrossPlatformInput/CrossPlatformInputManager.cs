namespace UnityStandardAssets.CrossPlatformInput
{
	public class CrossPlatformInputManager
	{
	}
}
