using UnityEngine;

namespace UnityStandardAssets.Effects
{
	public class ExplosionFireAndDebris : MonoBehaviour
	{
		public Transform[] debrisPrefabs;
		public Transform firePrefab;
		public int numDebrisPieces;
		public int numFires;
	}
}
