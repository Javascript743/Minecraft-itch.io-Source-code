using UnityEngine;

namespace UnityStandardAssets.Effects
{
	public class SmokeParticles : MonoBehaviour
	{
		public AudioClip[] extinguishSounds;
	}
}
