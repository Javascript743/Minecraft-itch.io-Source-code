using UnityEngine;

namespace UnityStandardAssets.Effects
{
	public class AfterburnerPhysicsForce : MonoBehaviour
	{
		public float effectAngle;
		public float effectWidth;
		public float effectDistance;
		public float force;
	}
}
