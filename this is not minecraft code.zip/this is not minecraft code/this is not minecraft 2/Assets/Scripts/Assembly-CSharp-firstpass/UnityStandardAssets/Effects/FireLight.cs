using UnityEngine;

namespace UnityStandardAssets.Effects
{
	public class FireLight : MonoBehaviour
	{
	}
}
