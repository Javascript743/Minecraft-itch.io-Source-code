namespace UnityStandardAssets.Cameras
{
	public class PivotBasedCameraRig : AbstractTargetFollower
	{
	}
}
