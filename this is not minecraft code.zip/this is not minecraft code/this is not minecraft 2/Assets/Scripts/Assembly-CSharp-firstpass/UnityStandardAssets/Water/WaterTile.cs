using UnityEngine;

namespace UnityStandardAssets.Water
{
	public class WaterTile : MonoBehaviour
	{
		public PlanarReflection reflection;
		public WaterBase waterBase;
	}
}
