using UnityEngine;

namespace UnityStandardAssets.Water
{
	public class MeshContainer
	{
		public MeshContainer(Mesh m)
		{
		}

		public Mesh mesh;
		public Vector3[] vertices;
		public Vector3[] normals;
	}
}
