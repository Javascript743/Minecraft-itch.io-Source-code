namespace UnityStandardAssets.Water
{
	public class GerstnerDisplace : Displace
	{
	}
}
