using UnityEngine;

namespace UnityStandardAssets.Water
{
	public class SpecularLighting : MonoBehaviour
	{
		public Transform specularLight;
	}
}
