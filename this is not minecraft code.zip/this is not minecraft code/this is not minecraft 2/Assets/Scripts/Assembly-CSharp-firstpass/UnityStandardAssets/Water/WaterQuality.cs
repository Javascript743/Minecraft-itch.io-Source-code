namespace UnityStandardAssets.Water
{
	public enum WaterQuality
	{
		High = 2,
		Medium = 1,
		Low = 0,
	}
}
