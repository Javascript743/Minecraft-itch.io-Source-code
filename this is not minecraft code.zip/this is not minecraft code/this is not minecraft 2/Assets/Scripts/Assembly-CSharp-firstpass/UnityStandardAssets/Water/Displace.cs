using UnityEngine;

namespace UnityStandardAssets.Water
{
	public class Displace : MonoBehaviour
	{
	}
}
