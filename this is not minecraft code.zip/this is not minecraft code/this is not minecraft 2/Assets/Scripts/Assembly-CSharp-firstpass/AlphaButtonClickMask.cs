using UnityEngine;

public class AlphaButtonClickMask : MonoBehaviour
{
}
