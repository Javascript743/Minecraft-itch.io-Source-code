namespace TMPro
{
	public class TMP_UpdateManager
	{
		private TMP_UpdateManager()
		{
		}

	}
}
