namespace TMPro
{
	public class FastAction
	{
	}
}
