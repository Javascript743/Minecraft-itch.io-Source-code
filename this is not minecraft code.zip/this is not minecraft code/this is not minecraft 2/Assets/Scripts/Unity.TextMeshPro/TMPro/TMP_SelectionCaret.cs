using UnityEngine.UI;

namespace TMPro
{
	public class TMP_SelectionCaret : MaskableGraphic
	{
	}
}
