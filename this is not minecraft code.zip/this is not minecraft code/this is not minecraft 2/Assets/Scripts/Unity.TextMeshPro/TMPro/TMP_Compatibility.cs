namespace TMPro
{
	public class TMP_Compatibility
	{
	}
}
