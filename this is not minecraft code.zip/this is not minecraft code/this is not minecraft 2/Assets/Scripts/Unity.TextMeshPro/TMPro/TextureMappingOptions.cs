namespace TMPro
{
	public enum TextureMappingOptions
	{
		Character = 0,
		Line = 1,
		Paragraph = 2,
		MatchAspect = 3,
	}
}
