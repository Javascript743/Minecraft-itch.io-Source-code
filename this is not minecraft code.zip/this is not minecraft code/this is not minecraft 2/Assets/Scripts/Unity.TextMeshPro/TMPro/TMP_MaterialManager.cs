namespace TMPro
{
	public class TMP_MaterialManager
	{
	}
}
