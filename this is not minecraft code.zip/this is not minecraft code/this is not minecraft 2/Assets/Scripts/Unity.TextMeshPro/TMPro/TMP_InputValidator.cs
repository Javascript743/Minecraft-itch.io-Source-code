using System;
using UnityEngine;

namespace TMPro
{
	[Serializable]
	public class TMP_InputValidator : ScriptableObject
	{
	}
}
