namespace TMPro
{
	public class TMPro_ExtensionMethods
	{
	}
}
