namespace TMPro
{
	public enum FontFeatureLookupFlags
	{
		None = 0,
		IgnoreLigatures = 4,
		IgnoreSpacingAdjustments = 256,
	}
}
