namespace TMPro
{
	public class MaterialReferenceManager
	{
	}
}
