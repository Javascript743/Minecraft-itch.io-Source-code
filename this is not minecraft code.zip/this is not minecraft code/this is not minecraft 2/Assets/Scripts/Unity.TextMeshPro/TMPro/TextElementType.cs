namespace TMPro
{
	public enum TextElementType : byte
	{
		Character = 1,
		Sprite = 2,
	}
}
