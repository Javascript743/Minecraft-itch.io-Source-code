using System;

namespace TMPro
{
	[Serializable]
	public class TMP_Glyph : TMP_TextElement_Legacy
	{
	}
}
