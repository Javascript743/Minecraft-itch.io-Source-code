using System;
using System.Collections.Generic;
using UnityEngine.TextCore;

namespace TMPro
{
	[Serializable]
	public class KerningTable
	{
		public List<KerningPair> kerningPairs;
	}
}
