namespace TMPro
{
	public enum AtlasPopulationMode
	{
		Static = 0,
		Dynamic = 1,
	}
}
