using System;

namespace TMPro
{
	[Serializable]
	public class TMP_Character : TMP_TextElement
	{
	}
}
