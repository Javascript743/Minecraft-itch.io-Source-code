namespace TMPro
{
	public class TMP_TextUtilities
	{
	}
}
