using UnityEngine;

namespace TMPro
{
	public class TMP_ScrollbarEventHandler : MonoBehaviour
	{
		public bool isSelected;
	}
}
