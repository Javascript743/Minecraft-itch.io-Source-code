using UnityEngine;

namespace TMPro
{
	public class TMP_SpriteAnimator : MonoBehaviour
	{
	}
}
