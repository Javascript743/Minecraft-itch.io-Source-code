namespace TMPro
{
	public class TMPro_EventManager
	{
	}
}
