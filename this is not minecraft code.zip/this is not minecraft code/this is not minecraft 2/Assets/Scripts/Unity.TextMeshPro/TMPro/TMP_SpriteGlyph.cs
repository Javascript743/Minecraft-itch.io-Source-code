using System;
using UnityEngine.TextCore;
using UnityEngine;

namespace TMPro
{
	[Serializable]
	public class TMP_SpriteGlyph : Glyph
	{
		public Sprite sprite;
	}
}
