namespace TMPro
{
	public enum MaskingTypes
	{
		MaskOff = 0,
		MaskHard = 1,
		MaskSoft = 2,
	}
}
