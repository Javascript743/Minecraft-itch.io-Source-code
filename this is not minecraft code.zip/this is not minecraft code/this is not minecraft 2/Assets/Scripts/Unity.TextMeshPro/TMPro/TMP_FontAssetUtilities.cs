namespace TMPro
{
	public class TMP_FontAssetUtilities
	{
	}
}
