using System;

namespace UnityEngine.Timeline
{
	[Serializable]
	public class MarkerTrack : TrackAsset
	{
	}
}
