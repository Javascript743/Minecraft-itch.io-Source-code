using UnityEngine.Playables;

namespace UnityEngine.Timeline
{
	public class TimeNotificationBehaviour : PlayableBehaviour
	{
	}
}
