namespace UnityEngine.Timeline
{
	internal class WeightUtility
	{
	}
}
