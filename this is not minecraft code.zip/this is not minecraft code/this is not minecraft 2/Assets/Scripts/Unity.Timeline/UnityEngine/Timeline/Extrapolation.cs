namespace UnityEngine.Timeline
{
	internal class Extrapolation
	{
	}
}
