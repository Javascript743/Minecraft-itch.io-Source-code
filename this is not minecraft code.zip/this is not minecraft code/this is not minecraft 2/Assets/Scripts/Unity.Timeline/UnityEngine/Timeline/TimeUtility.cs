namespace UnityEngine.Timeline
{
	internal class TimeUtility
	{
	}
}
