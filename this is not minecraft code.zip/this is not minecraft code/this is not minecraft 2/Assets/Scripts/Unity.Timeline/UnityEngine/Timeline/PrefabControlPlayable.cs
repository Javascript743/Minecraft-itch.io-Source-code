using UnityEngine.Playables;

namespace UnityEngine.Timeline
{
	public class PrefabControlPlayable : PlayableBehaviour
	{
	}
}
