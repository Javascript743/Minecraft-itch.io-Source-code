using UnityEngine.Animations;

namespace UnityEngine.Timeline
{
	internal class AnimationPreviewUpdateCallback
	{
		public AnimationPreviewUpdateCallback(AnimationPlayableOutput output)
		{
		}

	}
}
