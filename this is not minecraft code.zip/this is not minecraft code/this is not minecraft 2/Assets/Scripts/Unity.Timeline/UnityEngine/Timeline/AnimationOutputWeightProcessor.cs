using UnityEngine.Animations;

namespace UnityEngine.Timeline
{
	internal class AnimationOutputWeightProcessor
	{
		public AnimationOutputWeightProcessor(AnimationPlayableOutput output)
		{
		}

	}
}
