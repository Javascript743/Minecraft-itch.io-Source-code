namespace UnityEngine.Timeline
{
	internal class RuntimeElement
	{
	}
}
