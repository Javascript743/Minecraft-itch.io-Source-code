using UnityEngine.Playables;

namespace UnityEngine.Timeline
{
	internal class RuntimeClip : RuntimeClipBase
	{
		public RuntimeClip(TimelineClip clip, Playable clipPlayable, Playable parentMixer)
		{
		}

	}
}
