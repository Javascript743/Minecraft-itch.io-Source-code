namespace UnityEngine.Timeline
{
	internal class RuntimeClipBase : RuntimeElement
	{
	}
}
