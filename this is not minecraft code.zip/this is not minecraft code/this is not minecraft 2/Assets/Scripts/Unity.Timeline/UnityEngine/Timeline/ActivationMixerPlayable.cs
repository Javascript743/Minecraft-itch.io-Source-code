using UnityEngine.Playables;

namespace UnityEngine.Timeline
{
	internal class ActivationMixerPlayable : PlayableBehaviour
	{
	}
}
