using UnityEngine;

namespace UnityEngine.Timeline
{
	public class SignalAsset : ScriptableObject
	{
	}
}
