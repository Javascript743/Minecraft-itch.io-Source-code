namespace UnityEngine.Timeline
{
	internal class TimelineCreateUtilities
	{
	}
}
