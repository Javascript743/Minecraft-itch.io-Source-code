namespace UnityEngine.Timeline
{
	internal class TimelineUndo
	{
	}
}
