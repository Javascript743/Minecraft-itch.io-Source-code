namespace UnityEngine.Timeline
{
	internal class NotificationUtilities
	{
	}
}
