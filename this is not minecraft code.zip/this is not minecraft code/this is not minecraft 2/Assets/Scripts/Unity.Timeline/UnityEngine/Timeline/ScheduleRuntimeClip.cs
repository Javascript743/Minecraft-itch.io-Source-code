using UnityEngine.Playables;

namespace UnityEngine.Timeline
{
	internal class ScheduleRuntimeClip : RuntimeClipBase
	{
		public ScheduleRuntimeClip(TimelineClip clip, Playable clipPlayable, Playable parentMixer, double startDelay, double finishTail)
		{
		}

	}
}
