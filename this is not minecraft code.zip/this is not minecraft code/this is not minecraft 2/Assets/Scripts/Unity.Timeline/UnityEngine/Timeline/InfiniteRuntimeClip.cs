using UnityEngine.Playables;

namespace UnityEngine.Timeline
{
	internal class InfiniteRuntimeClip : RuntimeElement
	{
		public InfiniteRuntimeClip(Playable playable)
		{
		}

	}
}
