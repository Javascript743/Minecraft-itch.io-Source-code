using System;

namespace UnityEngine.Timeline
{
	public class TrackColorAttribute : Attribute
	{
		public TrackColorAttribute(float r, float g, float b)
		{
		}

	}
}
