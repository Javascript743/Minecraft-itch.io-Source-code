using UnityEngine;

namespace UnityEngine.Timeline
{
	public class Marker : ScriptableObject
	{
		[SerializeField]
		private double m_Time;
	}
}
