using System;

namespace UnityEngine.Timeline
{
	[Serializable]
	public class SignalTrack : MarkerTrack
	{
	}
}
