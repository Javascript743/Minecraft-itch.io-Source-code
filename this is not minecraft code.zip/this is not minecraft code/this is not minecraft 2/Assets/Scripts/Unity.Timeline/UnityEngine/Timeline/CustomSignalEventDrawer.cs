using UnityEngine;

namespace UnityEngine.Timeline
{
	internal class CustomSignalEventDrawer : PropertyAttribute
	{
	}
}
