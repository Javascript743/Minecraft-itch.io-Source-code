namespace UnityEngine.Timeline
{
	internal class HashUtility
	{
	}
}
