namespace UnityEngine.Timeline
{
	public enum TrackOffset
	{
		ApplyTransformOffsets = 0,
		ApplySceneOffsets = 1,
		Auto = 2,
	}
}
