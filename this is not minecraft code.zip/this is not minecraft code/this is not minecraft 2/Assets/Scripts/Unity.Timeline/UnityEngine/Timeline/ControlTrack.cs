namespace UnityEngine.Timeline
{
	public class ControlTrack : TrackAsset
	{
	}
}
