using UnityEngine;
using UnityEngine.UI;

public class CameraSwitch : MonoBehaviour
{
	public GameObject[] objects;
	public Text text;
}
