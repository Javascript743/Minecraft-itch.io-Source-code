using UnityEngine;

public class MenuSceneLoader : MonoBehaviour
{
	public GameObject menuUI;
}
