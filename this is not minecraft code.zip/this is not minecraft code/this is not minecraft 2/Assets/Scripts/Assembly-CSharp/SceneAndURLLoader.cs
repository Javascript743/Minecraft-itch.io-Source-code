using UnityEngine;

public class SceneAndURLLoader : MonoBehaviour
{
}
