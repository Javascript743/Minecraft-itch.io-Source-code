using UnityEngine;

public class WorldGenerator : MonoBehaviour
{
	public GameObject player;
	public int sizeX;
	public int sizeZ;
	public int groundHeight;
	public float terDetail;
	public float terHeight;
	public GameObject[] blocks;
}
